package columbusGame;

import java.util.Observable;
import java.util.concurrent.ThreadLocalRandom;

public class Ship extends Observable {
	
	Point location = new Point();
	OceanMap islandMap;
	
	public Ship(OceanMap map) {
		int x = ThreadLocalRandom.current().nextInt(0, 25);
		int y = ThreadLocalRandom.current().nextInt(0, 25);
		islandMap = map;
		while (islandMap.getMap()[x][y] == OceanMap.Tile.Island) {
			x = ThreadLocalRandom.current().nextInt(0, 25);
			y = ThreadLocalRandom.current().nextInt(0, 25);
		}
		location.setX(x);
		location.setY(y);
		islandMap.oceanGrid[x][y] = OceanMap.Tile.Columbus;
	};
	
	public Point getShipLocation() {
		return location;
	}
	
	public void setX(int x) {
		if (islandMap.getMap()[x][location.y] == OceanMap.Tile.Island) return;
		
		islandMap.oceanGrid[location.x][location.y] = OceanMap.Tile.Water;
		islandMap.oceanGrid[x][location.y] = OceanMap.Tile.Columbus;
		location.setX(x);
		setChanged();
		notifyObservers();
	}
	
	public void setY(int y) {

		if (islandMap.getMap()[location.x][y] == OceanMap.Tile.Island) return;
		
		islandMap.oceanGrid[location.x][location.y] = OceanMap.Tile.Water;
		islandMap.oceanGrid[location.x][y] = OceanMap.Tile.Columbus;
		location.setY(y);
		setChanged();
		notifyObservers();
	}

}

