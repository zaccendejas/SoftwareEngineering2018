package columbusGame;

import javafx.application.*;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.*;

public class OceanExplorer extends Application {
	
	OceanMap.Tile[][] islandMap;
	Pane root;
	final int dimensions = 25;
	final int islandCount =  10;
	final int scalingFactor = 30;
	Image shipImage;
	ImageView shipImageView;
	Image pirateImage1;
	ImageView pirateImageView1;
	Image pirateImage2;
	ImageView pirateImageView2;
	
	OceanMap oceanMap;
	Scene scene;
	Ship ship;
	Pirate pirate1;
	Pirate pirate2;
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		oceanMap = new OceanMap(dimensions, islandCount);
		islandMap = oceanMap.getMap();
		
		root = new AnchorPane();
		drawMap();
		addDetail();
		
		ship = new Ship(oceanMap);
		loadShipImage();
		
		pirate1 = new Pirate(oceanMap, scalingFactor);
		pirate2 = new Pirate(oceanMap, scalingFactor);
		loadPirateImage();
		
		ship.addObserver(pirate1);
		ship.addObserver(pirate2);
		
		scene = new Scene(root, 500, 500);
		primaryStage.setTitle("Homework4: Christopher Columbus Sails the Ocean Blue");
		primaryStage.setScene(scene);
		primaryStage.show();
		
		startSailing();
		
		
	}

	private void loadPirateImage() {
		// TODO Auto-generated method stub
		pirateImage1 = new Image("images\\pirateship.gif", scalingFactor, scalingFactor, true, true);
		pirateImageView1 = new ImageView(pirateImage1);
		pirateImageView1.setX(pirate1.getShipLocation().x * scalingFactor);
		pirateImageView1.setY(pirate1.getShipLocation().y * scalingFactor);
		root.getChildren().add(pirateImageView1);
		
		pirateImage2 = new Image("images\\pirateship.gif", scalingFactor, scalingFactor, true, true);
		pirateImageView2 = new ImageView(pirateImage2);
		pirateImageView2.setX(pirate2.getShipLocation().x * scalingFactor);
		pirateImageView2.setY(pirate2.getShipLocation().y * scalingFactor);
		root.getChildren().add(pirateImageView2);
	}

	private void startSailing() {
		// TODO Auto-generated method stub
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {

			@Override
			public void handle(KeyEvent ke) {
				// TODO Auto-generated method stub
				int x = ship.getShipLocation().x;
				int y = ship.getShipLocation().y;
				switch(ke.getCode()) {
				case RIGHT:
					if (x < 24) {
						ship.setX(x+1);
						shipImageView.setX(ship.getShipLocation().x * scalingFactor);

						pirateImageView1.setX(pirate1.getShipLocation().x * scalingFactor);
						pirateImageView2.setX(pirate2.getShipLocation().x * scalingFactor);
						pirateImageView1.setY(pirate1.getShipLocation().y * scalingFactor);
						pirateImageView2.setY(pirate2.getShipLocation().y * scalingFactor);
					}
					break;
				case LEFT:
					if (x > 0) {
						ship.setX(x-1);
						shipImageView.setX(ship.getShipLocation().x * scalingFactor);
						
						pirateImageView1.setX(pirate1.getShipLocation().x * scalingFactor);
						pirateImageView2.setX(pirate2.getShipLocation().x * scalingFactor);
						pirateImageView1.setY(pirate1.getShipLocation().y * scalingFactor);
						pirateImageView2.setY(pirate2.getShipLocation().y * scalingFactor);
					}
					break;
				case UP:
					if (y > 0) {
						ship.setY(y-1);
						shipImageView.setY(ship.getShipLocation().y * scalingFactor);
						
						pirateImageView1.setY(pirate1.getShipLocation().y * scalingFactor);
						pirateImageView2.setY(pirate2.getShipLocation().y * scalingFactor);
						pirateImageView1.setX(pirate1.getShipLocation().x * scalingFactor);
						pirateImageView2.setX(pirate2.getShipLocation().x * scalingFactor);
					}
					break;
				case DOWN:
					if (y < 24) {
						ship.setY(y+1);
						shipImageView.setY(ship.getShipLocation().y * scalingFactor);
						
						pirateImageView1.setY(pirate1.getShipLocation().y * scalingFactor);
						pirateImageView2.setY(pirate2.getShipLocation().y * scalingFactor);
						pirateImageView1.setX(pirate1.getShipLocation().x * scalingFactor);
						pirateImageView2.setX(pirate2.getShipLocation().x * scalingFactor);
					}
					break;
				default:
					
					break;
				}
			}
			
		});
	}
	
	private void addDetail() {
		Image oceanImage = new Image("images\\ocean.jpg", scalingFactor, scalingFactor, true, true);
		Image islandImage = new Image("images\\island.png", scalingFactor, scalingFactor, true, true);
		for (int i = 0; i < 25; i++) {
			for (int j = 0; j < 25; j++) {
				if (oceanMap.getMap()[i][j] == OceanMap.Tile.Water) {
					ImageView oceanView = new ImageView(oceanImage);
					oceanView.setX(i * scalingFactor);
					oceanView.setY(j * scalingFactor);
					root.getChildren().add(oceanView);
				}
				if (oceanMap.getMap()[i][j] == OceanMap.Tile.Island) {
					ImageView islandView = new ImageView(islandImage);
					islandView.setX(i * scalingFactor);
					islandView.setY(j * scalingFactor);
					root.getChildren().add(islandView);
				}
			}
		}
	}

	private void loadShipImage() {
		// TODO Auto-generated method stub
		shipImage = new Image("images\\ColumbusShip.png", scalingFactor, scalingFactor, true, true);
		shipImageView = new ImageView(shipImage);
		shipImageView.setX(ship.getShipLocation().x * scalingFactor);
		shipImageView.setY(ship.getShipLocation().y * scalingFactor);
		root.getChildren().add(shipImageView);
	}

	private void drawMap() {
		// TODO Auto-generated method stub
		oceanMap.drawMap(root.getChildren(), scalingFactor);
		islandMap = oceanMap.getMap();
	}

	public static void main(String[] args) {
		launch(args);
	}
	
}
