package columbusGame;

import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ThreadLocalRandom;

public class Pirate implements Observer {
	
	Point location = new Point();
	OceanMap islandMap;
	int scalingFactor;
	
	public Pirate(OceanMap map, int scalingFactor) {
		this.scalingFactor = scalingFactor;
		int x = ThreadLocalRandom.current().nextInt(0, 25);
		int y = ThreadLocalRandom.current().nextInt(0, 25);
		islandMap = map;
		while (islandMap.getMap()[x][y] == OceanMap.Tile.Island || islandMap.getMap()[x][y] == OceanMap.Tile.Columbus) {
			x = ThreadLocalRandom.current().nextInt(0, 25);
			y = ThreadLocalRandom.current().nextInt(0, 25);
		}
		location.setX(x);
		location.setY(y);
	};
	
	public Point getShipLocation() {
		return location;
	}
	
	public void setX(int x) {
		if (islandMap.getMap()[x][location.y] == OceanMap.Tile.Island) return;
		
		location.setX(x);
	}
	
	public void setY(int y) {

		if (islandMap.getMap()[location.x][y] == OceanMap.Tile.Island) return;
		
		location.setY(y);
	}
	
	@Override
	public void update(Observable arg0, Object arg1) {
		// TODO Auto-generated method stub
		if (arg0 instanceof Ship) {
			Point columbusLocation = ((Ship)arg0).getShipLocation();
			if (location.x == columbusLocation.x && location.y < columbusLocation.y) {
				moveDown();
			}
			else if (location.x == columbusLocation.x && location.y > columbusLocation.y) {
				moveUp();
			}
			else if (location.x < columbusLocation.x && location.y == columbusLocation.y) {
				moveRight();
			}
			else if (location.x > columbusLocation.x && location.y == columbusLocation.y) {
				moveLeft();
			} else {
				int axisDirection = ThreadLocalRandom.current().nextInt(0, 2); // randomly decide to move along the x or y axis
				System.out.println(axisDirection);
				if (axisDirection == 0) { // x axis
					if (location.x < columbusLocation.x) {
						moveRight();
					}
					else if (location.x > columbusLocation.x) {
						moveLeft();
					}
				}else { // y axis
					if (location.y < columbusLocation.y) {
						moveDown();
					}
					else if (location.y > columbusLocation.y) {
						moveUp();
					}
				}
			}
		}
		
	}

	private void moveLeft() {
		// TODO Auto-generated method stub

		if (location.x == 0) {
			return; 
		}
		if (islandMap.getMap()[location.x-1][location.y] == OceanMap.Tile.Island) {
			return;
		}
		
		islandMap.getMap()[location.x][location.y] = OceanMap.Tile.Water;
		islandMap.getMap()[location.x-1][location.y] = OceanMap.Tile.Pirate;
		setX((location.x)-1);
		
	}

	private void moveRight() {
		// TODO Auto-generated method stub

		if (location.x == 24) {
			return; 
		}
		if (islandMap.getMap()[location.x+1][location.y] == OceanMap.Tile.Island) {
			return;
		}
		
		islandMap.getMap()[location.x][location.y] = OceanMap.Tile.Water;
		islandMap.getMap()[location.x+1][location.y] = OceanMap.Tile.Pirate;
		setX((location.x)+1);
	}

	private void moveUp() {
		// TODO Auto-generated method stub
		System.out.println("up");

		if (location.y == 0) {
			return; 
		}
		if (islandMap.getMap()[location.x][location.y-1] == OceanMap.Tile.Island) {
			return;
		}
		
		islandMap.getMap()[location.x][location.y] = OceanMap.Tile.Water;
		islandMap.getMap()[location.x][location.y-1] = OceanMap.Tile.Pirate;
		setY((location.y)-1);
	}

	private void moveDown() {
		// TODO Auto-generated method stub

		if (location.y == 24) { 
			return; 
		}
		if (islandMap.getMap()[location.x][location.y+1] == OceanMap.Tile.Island) {
			return;
		}
		islandMap.getMap()[location.x][location.y] = OceanMap.Tile.Water;
		islandMap.getMap()[location.x][location.y+1] = OceanMap.Tile.Pirate;
		setY((location.y)+1);
	}
	

}
