package columbusGame;

import java.util.concurrent.ThreadLocalRandom;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class OceanMap {
	
	public enum Tile {
		Water, Island, Columbus, Pirate
	}
	
	Tile[][] oceanGrid;
	int dimensions = 25;
	int islandCount;
	
	public OceanMap() {
		oceanGrid = new Tile[dimensions][dimensions];
	}
	
	public OceanMap(int dimensions, int islandCount) {
		this.dimensions = dimensions;
		oceanGrid = new Tile[dimensions][dimensions];
		this.islandCount = islandCount;
	}
	
	public void drawMap(ObservableList<Node> root, int scale) {
		for (int x = 0; x < dimensions; x++) {
			for (int y = 0; y < dimensions; y++) {
				Rectangle rect = new Rectangle(x*scale, y*scale, scale, scale);
				rect.setStroke(Color.BLACK);
				rect.setFill(Color.PALETURQUOISE);
				root.add(rect);
				oceanGrid[x][y] = Tile.Water;
			}
		}
		while (islandCount > 0) {
			int x = ThreadLocalRandom.current().nextInt(0, 25);
			int y = ThreadLocalRandom.current().nextInt(0, 25);
			if (oceanGrid[x][y] == Tile.Water) {
				Rectangle rect = new Rectangle(x*scale, y*scale, scale, scale);
				rect.setStroke(Color.BLACK);
				rect.setFill(Color.GREEN);
				root.add(rect);
				oceanGrid[x][y] = Tile.Island;
				islandCount--;
			}
		}
	}
	
	public Tile[][] getMap() {return oceanGrid;}
	

}
