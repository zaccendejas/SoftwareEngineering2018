package edu.nd.sarec.railwaycrossing.model.infrastructure;

public enum Direction {
    NORTH,
    SOUTH,
    EAST,
    WEST,
    CUSTOM;
}
