package edu.nd.sarec.railwaycrossing.model.infrastructure.gate;

import java.util.HashSet;

import edu.nd.sarec.railwaycrossing.model.vehicles.Train;

/**
 * Gate in opening state
 * @author jane
 *
 */
public class GateOpening implements IGateState{
	
	CrossingGate gate;
	HashSet<Train> conflictingTrains = new HashSet<Train>();
	
	protected GateOpening(CrossingGate gate){
		this.gate = gate;
	}

	@Override
	public void approachStation() {
		gate.setGateState(gate.getGateClosingState());		
	}

	@Override
	public void leaveStation() {
		// Already opening.		
	}

	@Override
	public void gateFinishedOpening() {
		gate.setGateState(gate.getGateOpenState());
	}

	@Override
	public void gateFinishedClosing() {
	    // not reachable except through error.
		// Raise an alarm!!
	}

	@Override
	public void operate() {
		gate.open();
		// Flash lights..	
	}
	
	@Override
	public String getTrafficAction() {
		return "STOP";
	}

	@Override
	public void addConflict(Train train) {
		// TODO Auto-generated method stub
		conflictingTrains.add(train);
	}

	@Override
	public void removeConflict(Train train) {
		// TODO Auto-generated method stub
		conflictingTrains.remove(train);
	}
	
}
