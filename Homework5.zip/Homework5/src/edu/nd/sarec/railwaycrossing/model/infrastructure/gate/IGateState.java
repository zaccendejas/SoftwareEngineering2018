package edu.nd.sarec.railwaycrossing.model.infrastructure.gate;

import edu.nd.sarec.railwaycrossing.model.vehicles.Train;

/**
 * Declares all operations that GateState classes must implement
 * @author jane
 *
 */
public interface IGateState {
	public void approachStation();
	public void leaveStation();
	public void gateFinishedOpening();
	public void gateFinishedClosing();
	public void operate();
	public String getTrafficAction();
	public void addConflict(Train train);
	public void removeConflict(Train train);
}
