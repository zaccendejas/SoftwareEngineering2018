package edu.nd.sarec.railwaycrossing.view;

public interface IDisplay {
	public void draw();
}
