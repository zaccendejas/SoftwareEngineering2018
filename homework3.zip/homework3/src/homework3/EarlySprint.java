package homework3;

public class EarlySprint extends Jockey {

	public float run(float distance, float speed) {
		if (distance < 2) distance += speed;
		else distance += speed*.75;
		
		return distance;
	}
}
