package homework3;

import java.util.*;

public class Race {
	
	public List<Horse> racers  = new ArrayList<Horse>();
	Horse champ = null;
	
	public Race() {}
	
	public void addHorse(Horse horse) {
		racers.add(horse);
	}
	
	public void start() {
		while(true) {
			
			boolean isWinner = false;
			
			for (Horse horse : racers) {
				float distance = horse.run();
				if (distance >= 10) {
					isWinner = true;
					champ = horse;
				}
				System.out.println(horse.name + " has run " + horse.distanceTraveled + "...");
			}
			
			System.out.println('\n');
			if (isWinner) break;
			
		}
	}
	
	public void displayWinner() {
		
		System.out.println("The winner of the race is: " + champ.name);
		
	}
}
