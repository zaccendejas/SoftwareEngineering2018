package homework3;

public class SteadySprint extends Jockey {

	public float run(float distance, float speed) {
		
		distance += speed*.8;
		
		return distance;
	}
}
