package homework3;

public class Horse {
	
	float maxSpeed;
	float distanceTraveled;
	Jockey jockey;
	String name;
	
	public Horse(String name, float speed, Jockey jockey) {
		setName(name);
		setSpeed(speed);
		setJockey(jockey);
	}

	public void setSpeed(float speed) {
		maxSpeed = speed/60; //set speed given in mph in form of mpm (miles per minute)
	}
	
	public void setJockey(Jockey jockey) {
		this.jockey = jockey;
	}
	
	public Jockey getJockey() { return jockey;}
	
	public void setName(String name) {
		this.name = new String(name);
	}
	
	public float run() {
		distanceTraveled = jockey.run(distanceTraveled, maxSpeed);
		return distanceTraveled;
	}
}
