package homework3;

public class LateSprint extends Jockey {

	public float run(float distance, float speed) {
		if (distance < 6) distance += speed*.75;
		else if (distance < 9) distance += speed*.9;
		else distance += speed;
		
		return distance;
	}
}
