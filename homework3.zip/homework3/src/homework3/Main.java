package homework3;

public class Main {

	public Main() {}
	
	public static void main(String[] args) {
		
		Race bigRace = new Race();
		bigRace.addHorse(new Horse("Sam", 22, new EarlySprint()));
		bigRace.addHorse(new Horse("Molly", 24, new LateSprint()));
		bigRace.addHorse(new Horse("Joe", 25, new EarlySprint()));
		bigRace.addHorse(new Horse("Blizzard", 25, new LateSprint()));
		bigRace.addHorse(new Horse("Flicker", 25, new SteadySprint()));
		
		bigRace.start();
		
		bigRace.displayWinner();

	}
}
