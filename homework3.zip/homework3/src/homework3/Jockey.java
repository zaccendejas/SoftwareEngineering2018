package homework3;

public abstract class Jockey {

	public abstract float run(float distance, float speed);
	
}
