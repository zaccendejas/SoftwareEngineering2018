package homework3.tests;

import homework3.*;
import org.junit.Test;

public class StrategyTest {

	@Test
	public void test() {
		Horse test = new Horse("Test Horse", 25, new EarlySprint());
		assert(test.getJockey() instanceof EarlySprint);
		test.setJockey(new SteadySprint());
		assert(test.getJockey() instanceof SteadySprint);
		test.setJockey(new LateSprint());
		assert(test.getJockey() instanceof LateSprint);
	}

}
