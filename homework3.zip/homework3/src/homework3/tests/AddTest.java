package homework3.tests;

import homework3.*;
import org.junit.Test;

public class AddTest {

	@Test
	public void test() {
		Race test = new Race();
		assert(test.racers.size() == 0);
		test.addHorse(new Horse("Sam", 22, new EarlySprint()));
		assert(test.racers.size() == 1);
		test.addHorse(new Horse("Molly", 24, new LateSprint()));
		assert(test.racers.size() == 2);
		test.addHorse(new Horse("Joe", 25, new EarlySprint()));
		assert(test.racers.size() == 3);
		test.addHorse(new Horse("Blizzard", 25, new LateSprint()));
		assert(test.racers.size() == 4);
		test.addHorse(new Horse("Flicker", 25, new SteadySprint()));
		assert(test.racers.size() == 5);
	}

}
