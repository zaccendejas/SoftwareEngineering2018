package homework3.tests;

import homework3.*;
import org.junit.Test;

public class RunningAlgTest {

	@Test
	public void test() {
		Jockey test = new LateSprint();
		assert(test.run(2, 10) == 9.5);
		assert(test.run(7,  10) == 16);
		assert(test.run(9,  10) == 19);
	}

}
